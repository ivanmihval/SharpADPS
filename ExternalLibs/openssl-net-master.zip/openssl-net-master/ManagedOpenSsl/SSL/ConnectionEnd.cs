﻿// Copyright © Microsoft Open Technologies, Inc.
// All Rights Reserved       

namespace OpenSSL
{
    /// <summary>
    /// 
    /// </summary>
    public enum ConnectionEnd
    {
        /// <summary>
        /// 
        /// </summary>
        Client = 0,

        /// <summary>
        /// 
        /// </summary>
        Server = 1,
    }
}
